const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const { email } = JSON.parse(event.body);
    if (!email) return { statusCode: 400, body: JSON.stringify({ error: "Email required" }) };

    // Find customer by email
    const customers = await stripe.customers.list({ email, limit: 1 });
    if (!customers.data.length) {
      return { statusCode: 200, body: JSON.stringify({ plan: "trial", status: null }) };
    }

    const customer = customers.data[0];

    // Get active subscription
    const subscriptions = await stripe.subscriptions.list({
      customer: customer.id,
      status: "active",
      limit: 1,
    });

    if (!subscriptions.data.length) {
      // Check for trialing
      const trialing = await stripe.subscriptions.list({
        customer: customer.id,
        status: "trialing",
        limit: 1,
      });
      if (trialing.data.length) {
        const sub = trialing.data[0];
        const priceId = sub.items.data[0]?.price?.id;
        return { statusCode: 200, body: JSON.stringify({ plan: "trial", status: "trialing", priceId }) };
      }
      return { statusCode: 200, body: JSON.stringify({ plan: "trial", status: null }) };
    }

    const sub = subscriptions.data[0];
    const priceId = sub.items.data[0]?.price?.id;

    return {
      statusCode: 200,
      body: JSON.stringify({
        status: sub.status,
        priceId,
        currentPeriodEnd: sub.current_period_end,
        cancelAtPeriodEnd: sub.cancel_at_period_end,
      }),
    };

  } catch (error) {
    console.error("get-subscription error:", error);
    return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
  }
};
